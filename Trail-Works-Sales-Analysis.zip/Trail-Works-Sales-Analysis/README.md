Trail-Works-Sales-Dashboard/
│
├── 📊 PowerBI/
│   └── TrailWorks_Sales_Dashboard.pbix
│
├── 📁 Data/
│   └── TrailWorks_Sales_Data.csv
│
├── 📁 Reports/
│   ├
│   └── dashboard_screenshot.png
│
├── 📁 Docs/
│   └── README.md
